/**
 ****************************************************************************************
 *
 * @file scatter_common.h
 *
 * @brief decalare the symbols in scatter_common.sct.
 *
 *
 ****************************************************************************************
 */

#ifndef __SCATTER_COMMON_H__
#define __SCATTER_COMMON_H__

#include <stdint.h>
#include "ble_cfg.h"

#endif // __SCATTER_COMMON_H__
