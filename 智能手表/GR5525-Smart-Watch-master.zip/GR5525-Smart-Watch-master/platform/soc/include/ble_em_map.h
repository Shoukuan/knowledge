#ifndef __BLE_EM_MAP__
#define __BLE_EM_MAP__

#define BLE_ACTIVITY_CUST    			0 
#define BLE_RAL_CUST         			0
#define BLE_ADV_BUF_NB_CUST  			0  
#define BLE_ADV_FRAG_NB_CUST 			0  
#define _EM_COMMON_OFFSET    			0     

#endif
