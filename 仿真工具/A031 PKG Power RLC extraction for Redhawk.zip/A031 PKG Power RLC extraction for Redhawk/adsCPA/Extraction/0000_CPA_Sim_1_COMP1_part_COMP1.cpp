*******************************************
* Sentinel-PSI SSO Channel Builder (2023 R2, * * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.)
                   *
*                                         *
* * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.
*  Job: D:\Persional\02 SIwave\07 CPA\Workflow\CPA Radhawk RLGC.siwaveresults\0000_CPA_Sim_1\ 0000_CPA_Sim_1                      
*******************************************
* CPP info for component = COMP1_part_COMP1           

* Begin Chip Package Protocol
* 
* Start Version Info
* CPP_Version 1.1
* Generator_Program SIwave_CPA 2023 R2
* End Version Info
* 
* Start Design Property
* DesignType Package
* End Design Property
*
* Start Package Property
* PkgType flipchip dieup
* End Package Property
*
* Start Units
* Length um
* End Units
*
* Start Power Ground Ports
* COMP1_part_COMP1-1 : (8.100000E+02 4.090000E+03) : Group_COMP1_part_COMP1_VDD_15_1  = VDD_15 : Group_COMP1_part_COMP1_VDD_15_1 : OTHER
* COMP1_part_COMP1-2 : (8.400000E+02 3.710000E+03) : Group_COMP1_part_COMP1_VSS_2  = VSS : Group_COMP1_part_COMP1_VSS_2 : OTHER
* End Power Ground Ports
*
* End Chip Package Protocol
