*******************************************
* Sentinel-PSI SSO Channel Builder (2023 R2, * * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.)
                   *
*                                         *
* * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.
*  Job: D:\Work\02_SIwave\07_CPA_Flow\A025 PCB RLC Extraction\PCB RLC Extraction.siwaveresults\0002_CPA_Sim_3\ 0002_CPA_Sim_3                      
*******************************************
* CPP info for component = E16347-001_C2B12           

* Begin Chip Package Protocol
* 
* Start Version Info
* CPP_Version 1.1
* Generator_Program SIwave_CPA 2023 R2
* End Version Info
* 
* Start Design Property
* DesignType Board
* End Design Property
*
*
* Start Units
* Length um
* End Units
*
* Start Power Ground Ports
* E16347-001_C2B12-1 : (4.747260E+04 1.813560E+04) : Group_E16347-001_C2B12_V1P0_S0_2  = V1P0_S0 : Group_E16347-001_C2B12_V1P0_S0_2 : OTHER
* E16347-001_C2B12-2 : (4.747260E+04 1.902460E+04) : Group_E16347-001_C2B12_GND_1  = GND : Group_E16347-001_C2B12_GND_1 : OTHER
* End Power Ground Ports
*
* End Chip Package Protocol
