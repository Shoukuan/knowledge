*******************************************
* Sentinel-PSI SSO Channel Builder (2023 R2, * * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.)
                   *
*                                         *
* * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.
*  Job: D:\Work\02_SIwave\07_CPA_Flow\A025 PCB RLC Extraction\PCB RLC Extraction.siwaveresults\0002_CPA_Sim_3\ 0002_CPA_Sim_3                      
*******************************************
* CPP info for component = XW_XW           

* Begin Chip Package Protocol
* 
* Start Version Info
* CPP_Version 1.1
* Generator_Program SIwave_CPA 2023 R2
* End Version Info
* 
* Start Design Property
* DesignType Board
* End Design Property
*
*
* Start Units
* Length um
* End Units
*
* Start Power Ground Ports
* XW_XW-2 : (7.325360E+04 2.537460E+04) : XW_GND_SINK_  = GND : XW_GND_SINK_ : DIE
* XW_XW-1 : (7.449820E+04 2.423160E+04) : XW_V1P0_S0_SINK_  = V1P0_S0 : XW_V1P0_S0_SINK_ : DIE
* End Power Ground Ports
*
* End Chip Package Protocol
