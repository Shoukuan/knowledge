*******************************************
* Sentinel-PSI SSO Channel Builder (2023 R2, * * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.)
                   *
*                                         *
* * ?1986-2023 ANSYS, Inc. All rights reserved. Unauthorized use, distribution, or duplication is prohibited. This product is subject to U.S. laws governing export and re-export.  For full Legal Notice, see documentation.
*  Job: D:\Work\02_SIwave\07_CPA_Flow\A025 PCB RLC Extraction\PCB RLC Extraction.siwaveresults\0002_CPA_Sim_3\ 0002_CPA_Sim_3                      
*******************************************
* CPP info for component = A36096-108_C3L22           

* Begin Chip Package Protocol
* 
* Start Version Info
* CPP_Version 1.1
* Generator_Program SIwave_CPA 2023 R2
* End Version Info
* 
* Start Design Property
* DesignType Board
* End Design Property
*
*
* Start Units
* Length um
* End Units
*
* Start Power Ground Ports
* A36096-108_C3L22-2 : (3.980180E+04 3.477260E+04) : Group_A36096-108_C3L22_GND_1  = GND : Group_A36096-108_C3L22_GND_1 : OTHER
* A36096-108_C3L22-1 : (4.069080E+04 3.477260E+04) : Group_A36096-108_C3L22_V1P0_S0_2  = V1P0_S0 : Group_A36096-108_C3L22_V1P0_S0_2 : OTHER
* End Power Ground Ports
*
* End Chip Package Protocol
